
public class Main extends GUI {
    public static void main(String[] args) {

        GUI myGUI = new GUI();
        while (!myGUI.checkSimpleGameWinner()) {
        }
    }
}


